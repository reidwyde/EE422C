package assignment1;
public class SortTools {
	public static boolean isSorted(int[] x, int n) {
		return false;
	}
	public static int[] insertGeneral(int[] x, int a, int b) {
        return null;
    }
	public static int find(int[] x, int a, int b) {
        return 3;
    }
}
